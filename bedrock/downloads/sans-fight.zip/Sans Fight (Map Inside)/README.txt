{\rtf1\ansi\ansicpg1252\cocoartf1404\cocoasubrtf460
{\fonttbl\f0\fswiss\fcharset0 Helvetica;}
{\colortbl;\red255\green255\blue255;}
\margl1440\margr1440\vieww10800\viewh8400\viewkind0
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural\partightenfactor0

\f0\fs24 \cf0 HIGHLY IMPORTANT!!!!\
\
IT IS OF UPMOST IMPORTANCE THAT YOU TURN ON HARD MODE     BEFORE    THE FIGHT!\
\
Also make sure to follow the rules, and only break blocks when told to (you\'92ll see).\
\
Thanks for downloading this map! I would highly appreciate if people will do a full review, credit me, and then show me them playing it! I really want to see somebody try this map!\
\
SANS FIGHT v.1.0\
\
version 0.15.6 and up\'85}